import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import { GoogleCalendarAdapter } from './services/googleSync';
import { generateBriefing } from './services/geminiService';
import { 
  Entity, 
  Relationship, 
  Message, 
  EntityKind, 
  EntityStatus, 
  RelationshipType, 
  ToonOperation,
  ToonOperationType,
  SyncQueueItem,
  ViewType,
  UserSettings,
  DebugLogEntry,
  FocusSession,
  DailyBriefing,
  RecurrenceType,
  Toast,
  TagDefinition
} from './types';

// --- Normalization & Validation Helper ---

const normalizePayload = (type: ToonOperationType, payload: any): any => {
  if (!payload) return {};
  const p = { ...payload };

  // 1. Common Field Aliases (LLM Hallucination Fixes)
  if (p.name && !p.title) p.title = p.name;
  if (p.desc && !p.description) p.description = p.desc;
  if (p.details && !p.description) p.description = p.details;
  if (p.notes && !p.description) p.description = p.notes; // Common for tasks
  
  // Date aliases
  if (p.due_date && !p.deadline) p.deadline = p.due_date;
  if (p.target_date && !p.deadline) p.deadline = p.target_date;
  if (p.end && !p.deadline) p.deadline = p.end; // Contextual, but safe fallback
  if (p.date && !p.start_time) p.start_time = p.date;
  if (p.start && !p.start_time) p.start_time = p.start;

  // 2. Relationship Aliases
  if (type === 'link_entities' || type === 'unlink_entities') {
      // Source
      if (!p.from && p.source) p.from = p.source;
      if (!p.from && p.source_id) p.from = p.source_id;
      if (!p.from && p.from_entity_id) p.from = p.from_entity_id;
      if (!p.from && p.origin) p.from = p.origin;

      // Target
      if (!p.to && p.target) p.to = p.target;
      if (!p.to && p.target_id) p.to = p.target_id;
      if (!p.to && p.to_entity_id) p.to = p.to_entity_id;
      if (!p.to && p.destination) p.to = p.destination;

      // Type
      if (!p.type && p.relationship) p.type = p.relationship;
      if (!p.type && p.rel) p.type = p.rel;
      
      // Default type if missing
      if (!p.type) p.type = RelationshipType.DEPENDS_ON;
  }
  
  // 3. Kind Validation/Normalization
  if (p.kind) {
      const k = p.kind.toUpperCase();
      if (Object.values(EntityKind).includes(k)) {
          p.kind = k;
      } else {
          // Fallback mapping
          if (k === 'MEETING') p.kind = EntityKind.EVENT;
          else if (k === 'REMINDER') p.kind = EntityKind.TASK;
          else if (k === 'SUBTASK') p.kind = EntityKind.TASK;
          else if (k === 'IDEA') p.kind = EntityKind.NOTE;
          else if (k === 'AREA' || k === 'DOMAIN' || k === 'SPACE') p.kind = EntityKind.CONTEXT;
          else p.kind = EntityKind.TASK; // Default
      }
  }

  return p;
};

// --- Helper: Calculate Next Recurrence ---
const calculateNextDate = (currentDate: string, recurrence: RecurrenceType): string | null => {
    if (!currentDate || !recurrence) return null;
    const date = new Date(currentDate);
    
    switch (recurrence) {
        case 'DAILY': date.setDate(date.getDate() + 1); break;
        case 'WEEKLY': date.setDate(date.getDate() + 7); break;
        case 'MONTHLY': date.setMonth(date.getMonth() + 1); break;
        case 'YEARLY': date.setFullYear(date.getFullYear() + 1); break;
        default: return null;
    }
    return date.toISOString();
};

// --- Helper: Resolve ID from ID or Title ---
const resolveEntityId = (identifier: string, entities: Entity[]): string | null => {
    if (!identifier) return null;
    // 1. Direct ID match
    const byId = entities.find(e => e.id === identifier);
    if (byId) return byId.id;

    // 2. Title match (Case insensitive, search backwards to find most recently created)
    // We search backwards because if the user says "Create Task A" and then "Link Task A",
    // they likely mean the one just created.
    for (let i = entities.length - 1; i >= 0; i--) {
        if (entities[i].title.toLowerCase() === identifier.toLowerCase()) {
            return entities[i].id;
        }
    }
    return null;
};

// --- Store Definition ---

interface HistorySnapshot {
    entities: Entity[];
    relationships: Relationship[];
    timestamp: number;
}

interface FlowmateState {
  isHydrated: boolean;
  entities: Entity[];
  relationships: Relationship[];
  universalTags: TagDefinition[];
  messages: Message[];
  pendingOps: {
    ops: ToonOperation[];
    originalMessageId: string;
  } | null;
  syncQueue: SyncQueueItem[];
  currentView: ViewType;
  selectedEntityId: string | null;
  settings: UserSettings;
  debugLogs: DebugLogEntry[];
  focusSession: FocusSession | null;
  dailyBriefing: DailyBriefing | null;
  
  // UI State
  isZenMode: boolean;
  toasts: Toast[];
  showConfetti: boolean;
  
  // History
  history: HistorySnapshot[];
  historyPointer: number;

  // Actions
  setHydrated: (val: boolean) => void;
  addMessage: (role: 'user' | 'assistant', text: string, ops?: ToonOperation[], attachment?: string | null) => string;
  setPendingOps: (ops: ToonOperation[], messageId: string) => void;
  clearPendingOps: () => void;
  applyOperations: (ops: ToonOperation[]) => void;
  processSyncQueue: () => Promise<void>;
  getSnapshot: () => { entities: Entity[]; relationships: Relationship[] };
  setView: (view: ViewType) => void;
  selectEntity: (id: string | null) => void;
  updateSettings: (settings: Partial<UserSettings>) => void;
  addDebugLog: (type: DebugLogEntry['type'], summary: string, details?: any) => void;
  clearDebugLogs: () => void;
  importData: (data: Partial<FlowmateState>) => void;
  
  // Toggle UI
  toggleZenMode: () => void;
  addToast: (message: string, type?: Toast['type']) => void;
  removeToast: (id: string) => void;
  triggerConfetti: () => void;

  // Undo/Redo
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;

  // Focus Timer Actions
  startFocusSession: (entityId: string, durationMinutes?: number) => void;
  endFocusSession: () => void;
  
  // AI Actions
  refreshDailyBriefing: () => Promise<void>;

  // Quick CRUD helpers for the Orchestrator
  findEntityByTitle: (title: string) => Entity | undefined;
  
  // Computed
  getXP: () => number;
}

export const useStore = create<FlowmateState>()(
  persist(
    (set, get) => ({
      isHydrated: false,
      entities: [],
      relationships: [],
      universalTags: [], // Initialize empty, will be populated if needed by migration
      messages: [
        {
            id: 'init-1',
            role: 'assistant',
            text: 'Welcome to Flowmate. I am ready to organize your productivity graph. What are you working on?',
            created_at: new Date().toISOString()
        }
      ],
      pendingOps: null,
      syncQueue: [],
      currentView: 'chat_graph',
      selectedEntityId: null,
      settings: {
        timezone: 'Asia/Kolkata', // Force IST
        preferred_model: 'gemini-2.5-flash',
        sync_enabled: false,
        debug_mode: false,
        custom_instructions: ''
      },
      debugLogs: [],
      focusSession: null,
      dailyBriefing: null,
      isZenMode: false,
      toasts: [],
      showConfetti: false,
      history: [],
      historyPointer: -1,

      setHydrated: (val) => set({ isHydrated: val }),

      setView: (view) => set({ currentView: view }),
      
      selectEntity: (id) => set({ selectedEntityId: id }),

      toggleZenMode: () => set(state => ({ isZenMode: !state.isZenMode })),

      addToast: (message, type = 'info') => {
          const id = uuidv4();
          set(state => ({ toasts: [...state.toasts, { id, message, type }] }));
          setTimeout(() => {
              get().removeToast(id);
          }, 3000);
      },

      removeToast: (id) => set(state => ({ toasts: state.toasts.filter(t => t.id !== id) })),

      triggerConfetti: () => {
          set({ showConfetti: true });
          setTimeout(() => set({ showConfetti: false }), 2500);
      },

      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings }
      })),

      addDebugLog: (type, summary, details) => {
        const state = get();
        if (!state.settings?.debug_mode) return;

        set(state => ({
          debugLogs: [
            {
              id: uuidv4(),
              timestamp: new Date().toISOString(),
              type,
              summary,
              details: details || {}
            },
            ...(state.debugLogs || []).slice(0, 49)
          ]
        }));
      },

      clearDebugLogs: () => set({ debugLogs: [] }),

      importData: (data) => {
          set((state) => ({
              entities: data.entities || [],
              relationships: data.relationships || [],
              messages: data.messages || [],
              settings: { ...state.settings, ...(data.settings || {}) },
              history: [], // Reset history on import
              historyPointer: -1,
              universalTags: data.universalTags || [] // Import tags if available
          }));
      },

      addMessage: (role, text, ops, attachment) => {
        const id = uuidv4();
        const newMessage: Message = {
          id,
          role,
          text,
          attachment: attachment || null,
          created_at: new Date().toISOString(),
          ops_preview: ops
        };
        set((state) => ({ messages: [...(state.messages || []), newMessage] }));
        return id;
      },

      setPendingOps: (ops, messageId) => {
        set({ pendingOps: { ops, originalMessageId: messageId } });
      },

      clearPendingOps: () => {
        set({ pendingOps: null });
      },

      startFocusSession: (entityId, durationMinutes = 25) => {
          set({
              focusSession: {
                  entityId,
                  startTime: new Date().toISOString(),
                  durationMinutes,
                  status: 'active'
              }
          });
      },

      endFocusSession: () => {
          set({ focusSession: null });
      },

      refreshDailyBriefing: async () => {
          const { entities, relationships } = get();
          const today = new Date().toISOString().split('T')[0];
          
          try {
             const content = await generateBriefing({ entities, relationships });
             set({
                 dailyBriefing: {
                     content,
                     timestamp: new Date().toISOString(),
                     generated_for_date: today
                 }
             });
          } catch (err) {
              console.error("Failed to generate briefing", err);
          }
      },

      getSnapshot: () => {
        const { entities, relationships } = get();
        return { entities: entities || [], relationships: relationships || [] };
      },

      findEntityByTitle: (title) => {
        if (!title) return undefined;
        return (get().entities || []).find(e => (e.title || '').toLowerCase() === title.toLowerCase());
      },
      
      getXP: () => {
          const { entities } = get();
          let xp = 0;
          (entities || []).forEach(e => {
              if (e.status === EntityStatus.COMPLETED) {
                  if (e.kind === EntityKind.PROJECT) xp += 100;
                  else if (e.kind === EntityKind.GOAL) xp += 200;
                  else if (e.kind === EntityKind.TASK) xp += 20;
                  else if (e.kind === EntityKind.ACTIVITY) xp += 10;
                  else xp += 5;
              }
          });
          return xp;
      },

      undo: () => {
          const { history, historyPointer, addToast } = get();
          if (historyPointer >= 0) {
              const snapshot = history[historyPointer];
              set({
                  entities: snapshot.entities,
                  relationships: snapshot.relationships,
                  historyPointer: historyPointer - 1
              });
              addToast("Undone last action", "info");
          }
      },

      redo: () => {
          const { history, historyPointer, addToast } = get();
          if (historyPointer < history.length - 1) {
              const snapshot = history[historyPointer + 1];
              set({
                  entities: snapshot.entities,
                  relationships: snapshot.relationships,
                  historyPointer: historyPointer + 1
              });
              addToast("Redone last action", "info");
          }
      },

      canUndo: () => {
          return get().historyPointer >= 0;
      },

      canRedo: () => {
          const { history, historyPointer } = get();
          return historyPointer < history.length - 1;
      },

      processSyncQueue: async () => {
          const { syncQueue, settings, entities, addDebugLog } = get();
          if (!settings.sync_enabled || syncQueue.length === 0) return;

          const pending = syncQueue.filter(i => i.status === 'pending');
          if (pending.length === 0) return;

          set(state => ({
              syncQueue: state.syncQueue.map(i => 
                  pending.find(p => p.id === i.id) ? { ...i, status: 'in_progress' } : i
              )
          }));

          for (const item of pending) {
              try {
                  const result = await GoogleCalendarAdapter.syncEvent(item.op, settings, entities);
                  
                  if (result.success) {
                      addDebugLog('sync', `Synced ${item.op.type}`, { externalId: result.externalId });
                      set(state => ({
                          syncQueue: state.syncQueue.map(i => 
                              i.id === item.id ? { ...i, status: 'done' } : i
                          )
                      }));
                  } else {
                      throw new Error(result.error || "Unknown sync error");
                  }
              } catch (err) {
                  console.error("Sync failed for item", item.id, err);
                  addDebugLog('sync', `Sync failed: ${item.op.type}`, { error: String(err) });
                  set(state => ({
                      syncQueue: state.syncQueue.map(i => 
                          i.id === item.id ? { ...i, status: 'failed', attempts: i.attempts + 1 } : i
                      )
                  }));
              }
          }
      },

      applyOperations: (ops) => {
        const { addDebugLog, addToast, triggerConfetti } = get();

        set((state) => {
          // SAVE HISTORY SNAPSHOT
          const newHistory = state.history.slice(0, state.historyPointer + 1);
          newHistory.push({
              entities: state.entities,
              relationships: state.relationships,
              timestamp: Date.now()
          });
          if (newHistory.length > 20) newHistory.shift();
          const newPointer = newHistory.length - 1;

          let newEntities = [...(state.entities || [])];
          let newRelationships = [...(state.relationships || [])];
          let newUniversalTags = [...(state.universalTags || [])];
          
          const sideEffectOps: ToonOperation[] = [];

          ops.forEach(op => {
            try {
                const { type } = op;
                const payload = normalizePayload(type, op.payload);
                const now = new Date().toISOString();

                switch (type) {
                  case 'create_entity': {
                    if (!payload.title) {
                        throw new Error("Missing title for create_entity");
                    }
                    
                    const entity: Entity = {
                      id: payload.id || uuidv4(),
                      kind: payload.kind || EntityKind.TASK,
                      title: payload.title || 'Untitled',
                      description: payload.description || null,
                      status: EntityStatus.ACTIVE,
                      priority: payload.priority || 1,
                      start_time: payload.start_time || null,
                      end_time: payload.end_time || null,
                      deadline: payload.deadline || null,
                      duration_minutes: payload.duration_minutes || null,
                      recurrence: payload.recurrence || null,
                      metadata: payload.metadata || {},
                      created_at: now,
                      updated_at: now,
                      canonical_tags: []
                    };
                    newEntities.push(entity);
                    
                    // Universal Tag Sync: If entity is TAG or CONTEXT, add to universal list
                    if (entity.kind === EntityKind.TAG || entity.kind === EntityKind.CONTEXT) {
                        const existingTag = newUniversalTags.find(t => t.id === entity.id || t.title.toLowerCase() === entity.title.toLowerCase());
                        if (!existingTag) {
                            newUniversalTags.push({
                                id: entity.id,
                                title: entity.title,
                                kind: entity.kind,
                                usage_count: 0
                            });
                        }
                    }
                    break;
                  }

                  case 'update_entity': {
                    // Smart resolve: If ID not found, try finding by Title
                    let targetId = payload.id;
                    let targetEntity = newEntities.find(e => e.id === targetId);
                    
                    if (!targetEntity) {
                        const resolvedId = resolveEntityId(payload.id, newEntities);
                        if (resolvedId) {
                            targetId = resolvedId;
                            targetEntity = newEntities.find(e => e.id === targetId);
                        }
                    }

                    if (!targetEntity) {
                        addDebugLog('system', 'Skipped update_entity: Not found', { id: payload.id });
                        break;
                    }
                    
                    const updates = payload.fields || {};

                    // Handle Rename Sync for Tags
                    if (updates.title && (targetEntity.kind === EntityKind.TAG || targetEntity.kind === EntityKind.CONTEXT)) {
                         newUniversalTags = newUniversalTags.map(t => 
                            t.id === targetId ? { ...t, title: updates.title } : t
                         );
                         
                         // Note: We are NOT updating canonical_tags in all referenced entities here to avoid O(N^2) perf hit on simple rename.
                         // But for strict consistency, we should. For MVP, we skip this deep update.
                         // The UI will likely refetch relationship data anyway.
                    }

                    // Handle Recurrence & Celebration logic
                    if (updates.status === EntityStatus.COMPLETED && targetEntity.status !== EntityStatus.COMPLETED) {
                        triggerConfetti();
                        
                        if (targetEntity.recurrence) {
                            const nextStart = targetEntity.start_time ? calculateNextDate(targetEntity.start_time, targetEntity.recurrence) : null;
                            const nextDeadline = targetEntity.deadline ? calculateNextDate(targetEntity.deadline, targetEntity.recurrence) : null;
                            
                            if (nextStart || nextDeadline) {
                                    sideEffectOps.push({
                                        type: 'create_entity',
                                        payload: {
                                            title: targetEntity.title,
                                            kind: targetEntity.kind,
                                            description: targetEntity.description,
                                            priority: targetEntity.priority,
                                            status: EntityStatus.ACTIVE,
                                            start_time: nextStart,
                                            deadline: nextDeadline,
                                            recurrence: targetEntity.recurrence,
                                            canonical_tags: targetEntity.canonical_tags,
                                            metadata: { ...targetEntity.metadata, cloned_from: targetEntity.id }
                                        }
                                    });
                                    addDebugLog('system', 'Generated recurring task instance', { originalId: targetEntity.id });
                            }
                        }
                    }

                    newEntities = newEntities.map(e => 
                        e.id === targetId 
                        ? { ...e, ...updates, updated_at: now } 
                        : e
                    );
                    break;
                  }

                  case 'delete_entity': {
                    let targetId = payload.id;
                    if (!newEntities.find(e => e.id === targetId)) {
                        targetId = resolveEntityId(payload.id, newEntities) || targetId;
                    }
                    
                    // Remove from universal tags if applicable
                    newUniversalTags = newUniversalTags.filter(t => t.id !== targetId);

                    newEntities = newEntities.filter(e => e.id !== targetId);
                    newRelationships = newRelationships.filter(r => r.from !== targetId && r.to !== targetId);
                    break;
                  }

                  case 'link_entities': {
                    // Support from_temp and to_temp for batch referencing
                    let fromId = payload.from;
                    let toId = payload.to;

                    if (!fromId && payload.from_temp) {
                        fromId = resolveEntityId(payload.from_temp, newEntities);
                    }
                    if (!toId && payload.to_temp) {
                        toId = resolveEntityId(payload.to_temp, newEntities);
                    }

                    // Fallback to normal resolution
                    if (!fromId) fromId = resolveEntityId(payload.from, newEntities);
                    if (!toId) toId = resolveEntityId(payload.to, newEntities);

                    if (!fromId || !toId) {
                         addDebugLog('system', 'Skipped link_entities: Entity not found', { from: payload.from || payload.from_temp, to: payload.to || payload.to_temp });
                         break;
                    }

                    const exists = newRelationships.some(r => 
                        r.from === fromId && r.to === toId && r.type === payload.type
                    );
                    if (!exists) {
                        newRelationships.push({
                            id: uuidv4(),
                            from: fromId,
                            to: toId,
                            type: payload.type || RelationshipType.DEPENDS_ON,
                            meta: payload.meta || {},
                            created_at: now
                        });
                        
                        // SYNC TAGS: If type is TAGGED_WITH, update canonical_tags and usage count
                        if (payload.type === RelationshipType.TAGGED_WITH) {
                            const targetEntity = newEntities.find(e => e.id === toId);
                            if (targetEntity) {
                                // 1. Update source entity canonical_tags
                                newEntities = newEntities.map(e => {
                                    if (e.id === fromId) {
                                        const tags = new Set(e.canonical_tags || []);
                                        tags.add(targetEntity.title);
                                        return { ...e, canonical_tags: Array.from(tags) };
                                    }
                                    return e;
                                });

                                // 2. Update usage count in universalTags
                                newUniversalTags = newUniversalTags.map(t => 
                                    t.id === toId ? { ...t, usage_count: (t.usage_count || 0) + 1 } : t
                                );
                            }
                        }
                    }
                    break;
                  }
                  
                  case 'unlink_entities': {
                    if (!payload.from || !payload.to) break;
                    
                    const fromId = resolveEntityId(payload.from, newEntities);
                    const toId = resolveEntityId(payload.to, newEntities);
                    
                    if (fromId && toId) {
                        newRelationships = newRelationships.filter(r => 
                          !(r.from === fromId && r.to === toId && r.type === payload.type)
                        );
                        
                        // SYNC TAGS: If type is TAGGED_WITH, remove from canonical_tags
                        if (payload.type === RelationshipType.TAGGED_WITH) {
                             const targetEntity = newEntities.find(e => e.id === toId);
                             if (targetEntity) {
                                 // 1. Remove from source entity canonical_tags
                                 newEntities = newEntities.map(e => {
                                     if (e.id === fromId) {
                                         return { 
                                             ...e, 
                                             canonical_tags: (e.canonical_tags || []).filter(t => t !== targetEntity.title) 
                                         };
                                     }
                                     return e;
                                 });
                                 
                                 // 2. Decrement usage count
                                 newUniversalTags = newUniversalTags.map(t => 
                                    t.id === toId ? { ...t, usage_count: Math.max(0, (t.usage_count || 0) - 1) } : t
                                 );
                             }
                        }
                    }
                    break;
                  }

                  case 'log_activity': {
                    const actId = uuidv4();
                    const activity: Entity = {
                        id: actId,
                        kind: EntityKind.ACTIVITY,
                        title: payload.title || 'Activity Log',
                        description: payload.notes || payload.description || null,
                        status: EntityStatus.COMPLETED,
                        priority: 1,
                        start_time: payload.start_time || payload.timestamp || now,
                        end_time: payload.end_time || null,
                        deadline: null,
                        duration_minutes: payload.duration_minutes || 0,
                        recurrence: null,
                        metadata: {},
                        created_at: now,
                        updated_at: now,
                        canonical_tags: []
                    };
                    newEntities.push(activity);
                    triggerConfetti();

                    if (payload.linked_entity_id) {
                        const linkedId = resolveEntityId(payload.linked_entity_id, newEntities);
                        if (linkedId) {
                            newRelationships.push({
                                id: uuidv4(),
                                from: actId,
                                to: linkedId,
                                type: RelationshipType.FULFILLS,
                                meta: {},
                                created_at: now
                            });
                        }
                    }
                    break;
                  }

                  case 'set_goal_progress': {
                    const { goal_id, minutes, percent, note } = payload;
                    const resolvedGoalId = resolveEntityId(goal_id, newEntities);
                    
                    if (!resolvedGoalId) break;
                    
                    newEntities = newEntities.map(e => {
                      if (e.id === resolvedGoalId) {
                        const meta = { ...e.metadata };
                        if (minutes !== undefined) meta.progress_minutes = (meta.progress_minutes || 0) + minutes;
                        if (percent !== undefined) meta.progress_percent = percent;
                        if (note) meta.latest_progress_note = note;
                        return { ...e, metadata: meta, updated_at: now };
                      }
                      return e;
                    });
                    break;
                  }

                  case 'schedule_event': {
                    const evtId = payload.id || uuidv4();
                    const existingIndex = newEntities.findIndex(e => e.id === evtId);
                    const safeTitle = payload.title || "Scheduled Event";
                    
                    if (existingIndex >= 0) {
                      newEntities = newEntities.map(e => 
                        e.id === evtId 
                          ? { 
                              ...e, 
                              title: safeTitle,
                              start_time: payload.start_time || e.start_time,
                              end_time: payload.end_time || e.end_time,
                              metadata: { ...e.metadata, ...(payload.metadata || {}) },
                              updated_at: now
                            } 
                          : e
                      );
                    } else {
                      const eventEntity: Entity = {
                        id: evtId,
                        kind: EntityKind.EVENT,
                        title: safeTitle,
                        description: payload.description || null,
                        status: EntityStatus.ACTIVE,
                        priority: 1,
                        start_time: payload.start_time || null,
                        end_time: payload.end_time || null,
                        deadline: null,
                        duration_minutes: null, 
                        recurrence: payload.recurrence || null,
                        metadata: payload.metadata || {},
                        created_at: now,
                        updated_at: now,
                        canonical_tags: []
                    };
                      newEntities.push(eventEntity);
                    }
                    break;
                  }

                  case 'tag_update': {
                    // Deprecated: We now prefer linking entities.
                    // However, we keep basic support for bulk updates if they occur.
                    const { entity_id, tags } = payload;
                    const resolvedId = resolveEntityId(entity_id, newEntities);
                    
                    if (!resolvedId || !Array.isArray(tags)) break;
                    newEntities = newEntities.map(e => 
                      e.id === resolvedId 
                        ? { ...e, canonical_tags: tags, updated_at: now } 
                        : e
                    );
                    break;
                  }
                }
            } catch (err) {
                console.error(`Operation ${op.type} failed execution:`, err);
                addDebugLog('system', `Operation execution failed: ${op.type}`, { error: String(err), payload: op.payload });
            }
          });

          if (sideEffectOps.length > 0) {
              setTimeout(() => {
                  get().applyOperations(sideEffectOps);
              }, 100);
          }

          if (ops.length > 0) {
              const count = ops.length;
              const msg = count === 1 ? `Applied 1 operation` : `Applied ${count} operations`;
              addToast(msg, 'success');
          }

          const newSyncItems: SyncQueueItem[] = ops.map(op => ({
            id: uuidv4(),
            op,
            status: 'pending',
            attempts: 0,
            created_at: new Date().toISOString()
          }));

          const currentSyncQueue = state.syncQueue || [];

          return { 
            history: newHistory,
            historyPointer: newPointer,
            entities: newEntities, 
            relationships: newRelationships, 
            universalTags: newUniversalTags,
            pendingOps: null,
            syncQueue: [...currentSyncQueue, ...newSyncItems]
          };
        });

        get().processSyncQueue();
      }
    }),
    {
      name: 'flowmate-storage',
      version: 14, // Bumped to 14 for Tag System
      migrate: (persistedState: any, version) => {
        const state = persistedState as Partial<FlowmateState>;
        
        // Strict safe initialization of arrays to prevent "map of undefined"
        const safeEntities = Array.isArray(state.entities) ? state.entities : [];
        const safeRelationships = Array.isArray(state.relationships) ? state.relationships : [];
        const safeMessages = Array.isArray(state.messages) ? state.messages : [];
        const safeSyncQueue = Array.isArray(state.syncQueue) ? state.syncQueue : [];
        const safeDebugLogs = Array.isArray(state.debugLogs) ? state.debugLogs : [];
        let safeTags = Array.isArray(state.universalTags) ? state.universalTags : [];

        // Migration: Populate universalTags if empty but tags exist in entities
        if (version < 14 && safeTags.length === 0) {
            safeEntities.forEach(e => {
                if (e.kind === EntityKind.TAG || e.kind === EntityKind.CONTEXT) {
                    if (!safeTags.find(t => t.id === e.id)) {
                        safeTags.push({
                            id: e.id,
                            title: e.title,
                            kind: e.kind,
                            usage_count: 0 // Will be recalculated or 0 for now
                        });
                    }
                }
            });
            // Approximate usage count? Not strictly necessary for functionality, but nice.
            // We can calculate usage by scanning relationships.
            const usageMap: Record<string, number> = {};
            safeRelationships.forEach(r => {
                if (r.type === RelationshipType.TAGGED_WITH) {
                    usageMap[r.to] = (usageMap[r.to] || 0) + 1;
                }
            });
            safeTags = safeTags.map(t => ({
                ...t,
                usage_count: usageMap[t.id] || 0
            }));
        }

        const mergedSettings = {
            timezone: 'Asia/Kolkata', // Force IST fallback
            preferred_model: 'gemini-2.5-flash',
            sync_enabled: false,
            debug_mode: false,
            custom_instructions: '',
            ...(state.settings || {})
        };
        
        return {
            ...state,
            settings: mergedSettings,
            focusSession: state.focusSession || null,
            dailyBriefing: state.dailyBriefing || null,
            isHydrated: false,
            isZenMode: false,
            toasts: [],
            showConfetti: false,
            history: [],
            historyPointer: -1,
            // Deep sanitize entities
            entities: safeEntities.map(e => ({
                ...e, 
                recurrence: e.recurrence || null,
                canonical_tags: Array.isArray(e.canonical_tags) ? e.canonical_tags : []
            })),
            relationships: safeRelationships,
            universalTags: safeTags,
            messages: safeMessages,
            syncQueue: safeSyncQueue,
            debugLogs: safeDebugLogs
        };
      },
      onRehydrateStorage: () => (state) => {
          state?.setHydrated(true);
      }
    }
  )
);