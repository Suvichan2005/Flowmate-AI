import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { v4 as uuidv4 } from 'uuid';
import { X, Calendar, Clock, Tag, Link2, AlertCircle, Trash2, Edit3, Save, RotateCcw, Plus, CheckSquare, Square, ChevronRight, ArrowUpRight, Sparkles, Timer, Repeat, Wand2, Shield, ShieldAlert, CornerRightDown, CornerRightUp, Lightbulb, TrendingUp } from 'lucide-react';
import { EntityKind, EntityStatus, RelationshipType, RecurrenceType, ToonOperation } from '../types';
import SmartEditor from './SmartEditor';
import MarkdownText from './MarkdownText';
import { improveText } from '../services/geminiService';
import { calculateProgress } from '../utils/progressCalculation';

const EntityDetailPanel: React.FC = () => {
  const { selectedEntityId, selectEntity, entities, relationships, universalTags, setPendingOps, applyOperations, addMessage, startFocusSession } = useStore();
  
  // Local Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<{
    title: string;
    description: string;
    status: EntityStatus;
    priority: number;
    recurrence: RecurrenceType;
    tags: string[]; // These are just strings for UI, we diff them on save
    tagInput: string;
    startTime: string; // ISO String
    deadline: string; // ISO String
  } | null>(null);

  // Subtask & Linking State
  const [showAddSubtask, setShowAddSubtask] = useState(false);
  const [subtaskTitle, setSubtaskTitle] = useState('');
  
  const [showLinker, setShowLinker] = useState(false);
  const [linkSearch, setLinkSearch] = useState('');
  const [linkType, setLinkType] = useState<RelationshipType>(RelationshipType.DEPENDS_ON);
  
  const [aiGenerating, setAiGenerating] = useState(false);

  const entity = entities.find(e => e.id === selectedEntityId);
  
  // Reset editing state when selection changes
  useEffect(() => {
    setIsEditing(false);
    setShowAddSubtask(false);
    setShowLinker(false);
    setSubtaskTitle('');
    setLinkSearch('');
    if (entity) {
        setEditForm({
            title: entity.title,
            description: entity.description || '',
            status: entity.status,
            priority: entity.priority,
            recurrence: entity.recurrence,
            tags: entity.canonical_tags || [],
            tagInput: '',
            startTime: entity.start_time || '',
            deadline: entity.deadline || ''
        });
    }
  }, [entity?.id]);

  if (!selectedEntityId || !entity) return null;

  // Find relationships
  const relatedLinks = relationships.filter(r => r.from === entity.id || r.to === entity.id);
  
  // Distinguish children (Reverse PART_OF)
  const childrenLinks = relationships.filter(r => r.to === entity.id && r.type === RelationshipType.PART_OF);
  const childrenIds = new Set(childrenLinks.map(r => r.from));
  const childEntities = entities.filter(e => childrenIds.has(e.id));
  
  // Generic Links (excluding children to avoid duplication)
  const otherLinks = relatedLinks.filter(r => !(r.to === entity.id && r.type === RelationshipType.PART_OF));

  // Progress Calculation
  const progress = calculateProgress(entity, entities, relationships);

  // Helper to map technical types to human readable labels
  const getRelationshipLabel = (type: RelationshipType, isOutbound: boolean) => {
      switch (type) {
          case RelationshipType.DEPENDS_ON:
              return isOutbound ? "Blocked By" : "Blocks";
          case RelationshipType.PART_OF:
              return isOutbound ? "Part Of" : "Includes";
          case RelationshipType.PRECEDES:
              return isOutbound ? "Precedes" : "Follows";
          case RelationshipType.FULFILLS:
              return isOutbound ? "Fulfills" : "Fulfilled By";
          default:
              return isOutbound ? type : `Inbound ${type}`;
      }
  };

  const getRelationshipIcon = (label: string) => {
      if (label === "Blocked By") return <ShieldAlert size={12} className="text-orange-400" />;
      if (label === "Blocks") return <Shield size={12} className="text-red-400" />;
      if (label === "Part Of") return <CornerRightUp size={12} className="text-slate-400" />;
      if (label === "Includes") return <CornerRightDown size={12} className="text-slate-400" />;
      return <Link2 size={12} className="text-slate-500" />;
  };

  // Group links by Human Label
  const linksByType: Record<string, typeof otherLinks> = {};
  otherLinks.forEach(link => {
      const isOutbound = link.from === entity.id;
      const label = getRelationshipLabel(link.type, isOutbound);
      
      if (!linksByType[label]) linksByType[label] = [];
      linksByType[label].push(link);
  });

  const getRelatedEntity = (linkId: string, fromId: string, toId: string) => {
    const targetId = fromId === entity.id ? toId : fromId;
    return entities.find(e => e.id === targetId);
  };

  // Calculate Suggested Links based on shared tags
  const suggestedLinks = entities.filter(e => 
      e.id !== entity.id &&
      !relatedLinks.some(r => r.from === e.id || r.to === e.id) && // Not already linked
      e.canonical_tags && entity.canonical_tags &&
      e.canonical_tags.some(t => entity.canonical_tags.includes(t)) // Shares a tag
  ).slice(0, 3); // Top 3

  const handleDelete = () => {
    setPendingOps([
        {
            type: 'delete_entity',
            payload: { id: entity.id, title: entity.title }
        }
    ], 'manual-delete');
    selectEntity(null);
  };

  const handleSave = () => {
    if (!editForm) return;
    
    const updates: Record<string, any> = {};
    if (editForm.title !== entity.title) updates.title = editForm.title;
    if (editForm.description !== (entity.description || '')) updates.description = editForm.description;
    if (editForm.status !== entity.status) updates.status = editForm.status;
    if (editForm.priority !== entity.priority) updates.priority = editForm.priority;
    if (editForm.recurrence !== entity.recurrence) updates.recurrence = editForm.recurrence;
    
    // Dates
    if (editForm.startTime !== (entity.start_time || '')) updates.start_time = editForm.startTime || null;
    if (editForm.deadline !== (entity.deadline || '')) updates.deadline = editForm.deadline || null;

    const ops: ToonOperation[] = [];

    // 1. Basic Updates
    if (Object.keys(updates).length > 0) {
        ops.push({
            type: 'update_entity',
            payload: {
                id: entity.id,
                fields: updates
            }
        });
    }

    // 2. Tag Synchronization (Diffing logic)
    const currentTags = entity.canonical_tags || [];
    const newTags = editForm.tags;
    
    // Find tags to ADD
    const tagsToAdd = newTags.filter(t => !currentTags.includes(t));
    tagsToAdd.forEach(tagTitle => {
        // Check if universal tag exists
        const existingTag = universalTags.find(t => t.title.toLowerCase() === tagTitle.toLowerCase());
        
        if (existingTag) {
            // Link to existing
            ops.push({
                type: 'link_entities',
                payload: { from: entity.id, to: existingTag.id, type: RelationshipType.TAGGED_WITH }
            });
        } else {
            // Create new TAG entity + Link
            const newTagId = uuidv4();
            ops.push({
                type: 'create_entity',
                payload: { id: newTagId, title: tagTitle, kind: EntityKind.TAG, status: EntityStatus.ACTIVE }
            });
            ops.push({
                type: 'link_entities',
                payload: { from: entity.id, to: newTagId, type: RelationshipType.TAGGED_WITH }
            });
        }
    });

    // Find tags to REMOVE
    const tagsToRemove = currentTags.filter(t => !newTags.includes(t));
    tagsToRemove.forEach(tagTitle => {
        // Find entity ID for this tag
        // Note: canonical_tags are strings, so we look up in universalTags (fast) or entities (slow)
        const tagEntity = universalTags.find(t => t.title === tagTitle) || entities.find(e => e.title === tagTitle && (e.kind === EntityKind.TAG || e.kind === EntityKind.CONTEXT));
        
        if (tagEntity) {
            ops.push({
                type: 'unlink_entities',
                payload: { from: entity.id, to: tagEntity.id, type: RelationshipType.TAGGED_WITH }
            });
        }
    });

    if (ops.length > 0) {
        applyOperations(ops);
    }
    
    setIsEditing(false);
  };

  const handleCancel = () => {
     setIsEditing(false);
     setEditForm({
        title: entity.title,
        description: entity.description || '',
        status: entity.status,
        priority: entity.priority,
        recurrence: entity.recurrence,
        tags: entity.canonical_tags || [],
        tagInput: '',
        startTime: entity.start_time || '',
        deadline: entity.deadline || ''
     });
  };

  const handleAddTag = () => {
      if (!editForm || !editForm.tagInput.trim()) return;
      const newTag = editForm.tagInput.trim();
      // Case insensitive check for duplicates in current list
      if (!editForm.tags.some(t => t.toLowerCase() === newTag.toLowerCase())) {
          setEditForm({
              ...editForm,
              tags: [...editForm.tags, newTag], // Keep original casing for display until saved
              tagInput: ''
          });
      }
  };

  const handleRemoveTag = (tag: string) => {
      if (!editForm) return;
      setEditForm({
          ...editForm,
          tags: editForm.tags.filter(t => t !== tag)
      });
  };

  const handleCreateSubtask = (e: React.FormEvent) => {
      e.preventDefault();
      if (!subtaskTitle.trim()) return;

      const newId = uuidv4();
      applyOperations([
          {
              type: 'create_entity',
              payload: {
                  id: newId,
                  title: subtaskTitle,
                  kind: EntityKind.TASK,
                  status: EntityStatus.ACTIVE,
                  priority: 1
              }
          },
          {
              type: 'link_entities',
              payload: {
                  from: newId,
                  to: entity.id,
                  type: RelationshipType.PART_OF
              }
          }
      ]);
      setSubtaskTitle('');
      setShowAddSubtask(false);
  };

  const handleCreateLink = (targetId: string) => {
      applyOperations([{
          type: 'link_entities',
          payload: {
              from: entity.id,
              to: targetId,
              type: linkType
          }
      }]);
      setShowLinker(false);
      setLinkSearch('');
  };

  const toggleTaskStatus = (task: typeof entity) => {
      const newStatus = task.status === EntityStatus.COMPLETED ? EntityStatus.ACTIVE : EntityStatus.COMPLETED;
      applyOperations([{
          type: 'update_entity',
          payload: {
              id: task.id,
              fields: { status: newStatus }
          }
      }]);
  };

  const handleAiBreakdown = () => {
      if (confirm(`Ask AI to break down "${entity.title}" into subtasks?`)) {
          addMessage('user', `Please break down the ${entity.kind.toLowerCase()} "${entity.title}" into actionable subtasks. Create them and link them to it.`);
      }
  };

  const handleAiGenerateDescription = async () => {
      if (!editForm) return;
      setAiGenerating(true);
      try {
          const prompt = `Generate a concise, professional description for a ${entity.kind.toLowerCase()} titled "${entity.title}". Focus on actionable details.`;
          const desc = await improveText(prompt, 'expand');
          setEditForm(prev => prev ? ({ ...prev, description: desc }) : null);
      } catch (err) {
          console.error("AI Gen Failed", err);
      } finally {
          setAiGenerating(false);
      }
  };

  const handleStartFocus = () => {
      startFocusSession(entity.id);
  };

  const toDateTimeLocal = (isoStr: string) => {
      if (!isoStr) return '';
      const d = new Date(isoStr);
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
      return d.toISOString().slice(0, 16);
  };

  const fromDateTimeLocal = (val: string) => {
      if (!val) return '';
      return new Date(val).toISOString();
  };

  const linkCandidates = showLinker ? entities.filter(e => 
    e.id !== entity.id && 
    e.title.toLowerCase().includes(linkSearch.toLowerCase()) &&
    !relatedLinks.some(r => r.from === e.id || r.to === e.id)
  ).slice(0, 5) : [];

  // Autocomplete candidates for tags
  const tagCandidates = isEditing && editForm?.tagInput 
      ? universalTags.filter(t => t.title.toLowerCase().includes(editForm.tagInput.toLowerCase()) && !editForm.tags.includes(t.title)).slice(0, 5)
      : [];

  return (
    <div className="absolute top-0 right-0 h-full w-full md:w-[400px] bg-slate-900 border-l border-slate-800 shadow-2xl transform transition-transform duration-300 z-40 overflow-hidden flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 flex justify-between items-start bg-slate-900/95 backdrop-blur">
        <div className="flex-1 mr-4">
          <span className="text-xs font-mono uppercase bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded mb-2 inline-block">
            {entity.kind}
          </span>
          {isEditing ? (
              <input 
                type="text"
                value={editForm?.title}
                onChange={e => setEditForm(prev => prev ? ({ ...prev, title: e.target.value }) : null)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 rounded px-2 py-1 mt-1 font-bold text-lg focus:ring-2 focus:ring-indigo-500/50 outline-none"
              />
          ) : (
            <h2 className="text-xl font-bold text-slate-100 leading-tight break-words">{entity.title}</h2>
          )}
        </div>
        
        <div className="flex gap-2">
            {!isEditing && (
                <button 
                  onClick={() => setIsEditing(true)}
                  className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-indigo-400 transition-colors"
                  title="Edit Entity"
                >
                  <Edit3 size={18} />
                </button>
            )}
            <button 
              onClick={() => selectEntity(null)}
              className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {!isEditing && entity.status !== EntityStatus.COMPLETED && (
            <button 
                onClick={handleStartFocus}
                className="w-full py-2 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-300 border border-indigo-500/20 rounded-lg flex items-center justify-center gap-2 transition-colors font-medium"
            >
                <Timer size={18} /> Start Focus Session
            </button>
        )}

        {/* Status & Priority */}
        <div className="flex gap-4">
          <div className="flex-1 bg-slate-800/50 p-3 rounded-lg border border-slate-800">
             <span className="text-xs text-slate-500 uppercase tracking-wider block mb-1">Status</span>
             {isEditing ? (
                 <select 
                    value={editForm?.status}
                    onChange={e => setEditForm(prev => prev ? ({ ...prev, status: e.target.value as EntityStatus }) : null)}
                    className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-sm rounded p-1 outline-none"
                 >
                    {Object.values(EntityStatus).map(s => (
                        <option key={s} value={s}>{s}</option>
                    ))}
                 </select>
             ) : (
                <span className="text-sm font-medium text-slate-200">{entity.status}</span>
             )}
          </div>
          <div className="flex-1 bg-slate-800/50 p-3 rounded-lg border border-slate-800">
             <span className="text-xs text-slate-500 uppercase tracking-wider block mb-1">Priority</span>
             {isEditing ? (
                 <input 
                    type="number"
                    min="1"
                    max="5"
                    value={editForm?.priority}
                    onChange={e => setEditForm(prev => prev ? ({ ...prev, priority: parseInt(e.target.value) || 1 }) : null)}
                    className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-sm rounded p-1 outline-none"
                 />
             ) : (
                 <span className="text